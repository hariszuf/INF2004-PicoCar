#ifdef B5_FULL_TEST
#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include "scan_link.h"
#include "vehicle_controller.h"
#include "platform.h"
#include "range_policy.h"
#include "buddy5_servo.h"
#include "../../buddy5/ultrasonic.h"
#include "../../buddy1/telemetry.h"
#if TM_WIFI_MQTT
#include "../../../lib/libnet/lwip/mqtt_dashboard_ready.h"
#endif
static b5_core_t core;
static line_scan_status_t shared;
static bool reset_pending, abort_pending;
static uint32_t report_sequence;
#define B5_RAW_REPORT_MAX_AGE_MS 2000u
static void publish(uint32_t now,int angle,bool valid,uint32_t timestamp) {
 UW irq;
 line_scan_status_t s={core.state,core.fault,core.profile,core.front_clearance_mm,
                       angle,valid,timestamp,now};
 DI(irq); shared=s; EI(irq);
}
void line_scan_get_status(line_scan_status_t *s) { UW irq; DI(irq); *s=shared; EI(irq); }
void line_scan_reset(void) { UW irq; DI(irq); reset_pending=true; EI(irq); }
void line_scan_abort(void) { UW irq; DI(irq); abort_pending=true; EI(irq); }
static void emit(uint8_t type,int32_t a,int32_t b,uint32_t seq) {
 telemetry_message_t m={0};
 m.source=5; m.type=type; m.value_1=a; m.value_2=b; m.sequence=seq;
 m.flags=(core.profile.width_valid?1u:0u)|(core.profile.depth_valid?2u:0u)|16u|
         (core.front_clearance_mm==B5_CLEAR_FRONT_MM?32u:0u); /* provisional full test */
 (void)buddy1_telemetry_submit(&m);
}
static void scan_task(INT stacd,void *exinf) {
 uint32_t settled=0,last_ping=0,last_report=0,delivered=0,front_time=0,last_bad=0;
 uint8_t last_fault=0,last_fault_state=0,last_ok_state=0;   /* kept for telemetry after the fault clears */
 b5_state_t previous=(b5_state_t)99;
 b5_range_t readings[B5_SAMPLE_COUNT];
 unsigned count=0;
 int32_t close_candidate_mm=-1;
 unsigned close_batches=0;
 int angle=999;
 bool front_valid=false;
 bool raw_seen=false;
 ultrasonic_result_t last_raw={0};
 uint32_t last_raw_time=0;
 (void)stacd; (void)exinf;
 b5_core_init(&core,buddy5_clock_ms());
 for(;;) {
  uint32_t now=buddy5_clock_ms();
  b5_feedback_t feedback={0};
  UW irq;
  bool reset,abort;
  (void)line_controller_feedback(&feedback);
  DI(irq); reset=reset_pending; reset_pending=false; abort=abort_pending; abort_pending=false; EI(irq);
  if(reset && feedback.valid && feedback.stopped && !feedback.fault &&
     (uint32_t)(now-feedback.timestamp_ms)<=B5_FEEDBACK_MAX_AGE_MS) {
   uint32_t seq=core.next_request_id,id=core.profile.obstacle_id;
   b5_core_init(&core,now); core.next_request_id=seq; core.profile.obstacle_id=id;
   count=0; angle=999; front_valid=false; close_candidate_mm=-1; close_batches=0;
   raw_seen=false;
  }
  if(abort && !reset) b5_core_fail(&core,B5_FAULT_CONTROLLER,now);
  b5_core_update(&core,now,&feedback,NULL);
  bool positioning_mode=core.state==B5_PROCESSING;
  bool guard_mode=core.state==B5_LINE_RECOVERY ||
                  (core.state==B5_AVOIDING && core.phase==2);
  int wanted=b5_core_angle(&core);
  if(wanted!=angle) {
   count=0; front_valid=false;
   if(!buddy5_servo_set_angle(wanted)) b5_core_fail(&core,B5_FAULT_SERVO,now);
   else { angle=wanted; settled=now; }
  }
  if((b5_core_wants_range(&core) || guard_mode) &&
     (uint32_t)(now-settled)>=B5_SERVO_SETTLE_MS &&
     (uint32_t)(now-last_ping)>=B5_PING_INTERVAL_MS) {
   ultrasonic_result_t raw=ultrasonic_read();
   now=last_ping=buddy5_clock_ms();
   last_raw=raw; last_raw_time=now; raw_seen=true;
   b5_range_t reading=b5_range_from_raw(raw);
   bool no_echo=b5_range_no_echo(&reading);
   readings[count++]=reading;
   bool forward=angle==0;
   /* Keep normal line-follow detection filtered. During the bypass and other
    * commanded moves, publish each measured forward echo at its current pose:
    * alternating echo/no-echo batches must not make the guard go stale.
    * A no-echo result still needs the full three-reading confirmation. */
   bool motion_guard_mode=positioning_mode || guard_mode;
   bool urgent=forward && !no_echo && motion_guard_mode && (!reading.valid ||
       reading.distance_mm<=B5_GUARD_FRONT_MM+B5_FRONT_OVERHANG_MM);
   if(count==B5_SAMPLE_COUNT || urgent || (forward && !no_echo && motion_guard_mode)) {
    b5_range_t filtered=(urgent || (forward && !no_echo && motion_guard_mode))
                        ?reading:b5_filter(readings);
    if(core.state==B5_AVOIDING && core.phase<2 && !filtered.valid &&
       (uint32_t)(now-last_bad)>=1000u) {
     tm_printf((UB*)"[SCAN] retry invalid reading at angle=%d\n",angle);
     last_bad=now;
    }
    (void)line_controller_feedback(&feedback);
    /* During the return to the line the reading at the look-back angle is published too (with its angle). */
    if(forward || guard_mode) { front_valid=filtered.valid; front_time=now; }
    if(core.state==B5_SCANNING)
     tm_printf((UB*)"[SCAN] angle=%d echo=%d mm=%d\n",angle,filtered.valid && !b5_range_no_echo(&filtered),b5_range_no_echo(&filtered)?-1:(int)filtered.distance_mm);
    if(core.state==B5_MONITORING && !line_controller_active()) {
     /* Standby gathers front data without starting an obstacle scan. */
     core.front_clearance_mm=b5_front_clearance(&filtered);
    } else if(positioning_mode) {
     /* The initial turn is allowed with the obstacle ahead.  Keep updating
      * clearance so the following lateral translation starts only when clear. */
     core.front_clearance_mm=b5_front_clearance(&filtered);
    } else if(guard_mode) {
     /* One malformed HC-SR04 batch must not latch the whole run off. The
      * controller keeps the last clear observation for 600 ms; a confirmed
      * close return still stops immediately. */
     if(filtered.valid) {
      core.front_clearance_mm=b5_front_clearance(&filtered);
      /* With B5_BYPASS_IGNORE_GUARD the close return is still reported (the sonar check uses it) but no
       * longer faults the return to the line: people standing beside the track triggered it. */
      if(core.front_clearance_mm<=B5_GUARD_FRONT_MM && !B5_BYPASS_IGNORE_GUARD)
       b5_core_fail(&core,B5_FAULT_NO_ROUTE,now);
     }
    } else {
     b5_range_t *confirmed=&filtered;
     if(core.state==B5_MONITORING) {
      /* A malformed/noisy pulse is neither a clear path nor an obstacle.
       * Retry it on the next batch; do not latch the driving test off. */
      if(!filtered.valid && !b5_range_no_echo(&filtered)) {
       confirmed=NULL; close_candidate_mm=-1; close_batches=0;
      } else {
      int32_t clearance=b5_front_clearance(&filtered);
      if(filtered.valid && !b5_range_no_echo(&filtered) && clearance<=B5_STOP_FRONT_MM) {
       int32_t difference=clearance-close_candidate_mm;
       if(difference<0) difference=-difference;
       if(close_candidate_mm>=0 && difference<=60) ++close_batches;
       else { close_candidate_mm=clearance; close_batches=1; }
       /* Two matching 3-ping groups reject transient phantom echoes. */
       if(close_batches<2) confirmed=NULL;
      } else { close_candidate_mm=-1; close_batches=0; }
      }
     } else { close_candidate_mm=-1; close_batches=0; }
     b5_core_update(&core,now,&feedback,confirmed);
    }
    count=0;
   }
  }
  if(core.request.id && core.request.id!=delivered) {
   delivered=core.request.id;
   if(!line_controller_request(&core.request)) {
    if(core.state==B5_ERROR) delivered=0;
    else b5_core_fail(&core,B5_FAULT_CONTROLLER,now);
   }
  }
  if(core.state==B5_ERROR) { if(core.fault) { last_fault=(uint8_t)core.fault; last_fault_state=last_ok_state; } }
  else last_ok_state=(uint8_t)core.state;
  if(core.state!=previous) {
   tm_printf((UB*)"[SCAN] state=%s fault=%d width=%d side=%d offset=%d\n",
      (UB*)b5_state_name(core.state),core.fault,
      core.profile.width_valid?core.profile.width_mm:-1,core.profile.side,core.profile.offset_mm);
   previous=core.state;
  }
  if((uint32_t)(now-last_report)>=1000u
#if TM_WIFI_MQTT
     && mqtt_dashboard_ready()
#endif
  ) {
   uint32_t seq=++report_sequence;
   emit(50,core.state,core.fault,seq);
   emit(51,(core.profile.width_valid||core.profile.width_estimated)?core.profile.width_mm:-1,core.profile.depth_valid?core.profile.depth_high_mm:-1,seq);
   emit(52,core.profile.side,core.profile.offset_mm,seq);
   emit(54,core.front_clearance_mm==B5_CLEAR_FRONT_MM?-1:core.front_clearance_mm,angle,seq);
   emit(53,core.profile.depth_valid?core.profile.depth_low_mm:-1,core.profile.depth_valid?core.profile.depth_high_mm:-1,seq);
   emit(55,(int32_t)core.profile.obstacle_id,(int32_t)now,seq);
   /* value_2: extends (bits 0-7), the last obstacle fault (bits 8-15) and the state it happened in (bits 16-23).
    * These two stay after the fault is cleared, so a sudden stop can still be read from the log afterwards. */
   emit(56,(core.profile.width_valid?1:0)|(core.profile.depth_valid?2:0)|(core.edges_seen?4:0)|(core.profile.width_estimated?8:0)|16,
        (int32_t)core.extends|((int32_t)last_fault<<8)|((int32_t)last_fault_state<<16),seq);
   if(core.profile.side_reason!=B5_WHY_NONE) {
    /* Scan decision: value_1 = left edge (low 16 bits) and right edge (high 16 bits) in mm, signed, + = left of the
     * car; value_2 = why the side was chosen (bits 0-3), left/right edge measured (bits 4/5), heading re-turns
     * (bits 8-15), sonar extra turns (bits 16-23). Only sent once an obstacle has been scanned. */
    int32_t edges=(int32_t)(((uint32_t)core.profile.left_report_mm&0xFFFFu)|(((uint32_t)core.profile.right_report_mm&0xFFFFu)<<16));
    int32_t info=(core.profile.side_reason&15)|(core.profile.left_measured?16:0)|(core.profile.right_measured?32:0)|
                 ((int32_t)core.turn_fixes<<8)|((int32_t)core.block_fixes<<16)|(core.alt_tried?64:0)|((int32_t)(core.rescans&15)<<24);
    /* bit 6 = switched to the other side after the front check, bits 24-27 = rescans done */
    emit(B5_TELEM_DECISION,edges,info,seq);
   }
   /* Raw echo is separate from filtered front clearance; -1 means no fresh
    * measurement. Status follows ultrasonic_status_t (0..4). */
   bool raw_fresh=raw_seen && (uint32_t)(now-last_raw_time)<=B5_RAW_REPORT_MAX_AGE_MS;
   /* One packet for the vehicle execution status, kept small so the shared telemetry queue does not drop the
    * obstacle profile packets above. value_1 = state | last START result << 4,
    * value_2 = last stop reason | automatic restarts << 8. */
   emit(60,(b5_exec_state&15)|((b5_start_result&15)<<4),(b5_exec_reason&255)|(b5_auto_retries<<8),seq);
   if(core.profile.side_reason!=B5_WHY_NONE && seq%3u!=0u) {
    /* What the sonar saw at each scan angle, for diagnosing a wrong side choice. One byte per angle, -35 deg first,
     * 5 deg steps: 0 = not sampled, 1 = unusable reading, 255 = no echo, otherwise range in units of 4 mm.
     * 5/61 = angles -35..0 (value_1 = -35..-20, value_2 = -15..0), 5/62 = +5..+25 and the two looks taken by
     * pivoting the car (value_2 bytes 1-3, see below). Takes the raw-range packet's place in
     * two of every three reports so the number of packets stays the same. */
    uint32_t b[16]={0};
    for(unsigned i=0;i<B5_SCAN_POINTS;++i) if(core.scan.sampled[i]) {
     uint32_t q=core.scan.distance[i]/4u;
     b[i]=core.scan.valid[i]==B5_SCAN_NO_ECHO?255u:core.scan.valid[i]==B5_SCAN_ECHO?(q>254u?254u:q<2u?2u:q):1u;
    }
    /* Pivot looks: edge angle of each side in 15-degree units (left in the low 4 bits, right in the high 4:
     * 2 = 30 ... 5 = 75, 6 = still in view, 0 = not done / no reading), then the farthest box echo on each side. */
    b[13]=(((uint32_t)core.probe_left_deg+7u)/15u)|((((uint32_t)core.probe_right_deg+7u)/15u)<<4);
    b[14]=core.probe_left_reach/4u>254u?254u:core.probe_left_reach/4u;
    b[15]=core.probe_right_reach/4u>254u?254u:core.probe_right_reach/4u;
    unsigned o=seq%3u==1u?0u:8u;
    emit(seq%3u==1u?61:62,(int32_t)(b[o]|(b[o+1]<<8)|(b[o+2]<<16)|(b[o+3]<<24)),
         (int32_t)(b[o+4]|(b[o+5]<<8)|(b[o+6]<<16)|(b[o+7]<<24)),seq);
   } else
   emit(B5_TELEM_RAW_RANGE,raw_fresh && last_raw.status==US_OK?(int32_t)last_raw.distance_mm:-1,
        raw_fresh?(int32_t)last_raw.status:-1,seq);
   last_report=now;
  }
  publish(now,angle,front_valid,front_time);
  tk_dly_tsk(5);
 }
}
int32_t line_scan_start(void) {
 T_CTSK cfg={0};
 cfg.tskatr=TA_HLNG|TA_RNG3; cfg.task=scan_task; cfg.itskpri=11; cfg.stksz=4096;
 ID id=tk_cre_tsk(&cfg);
 if(id<0) return id;
 ER e=tk_sta_tsk(id,0);
 if(e<0) tk_del_tsk(id);
 return e;
}
#endif
