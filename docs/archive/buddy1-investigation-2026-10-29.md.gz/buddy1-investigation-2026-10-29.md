# Buddy 1 historical investigation records

These dated records preserve intermediate findings and do not replace the final review.
Local paths and narrative role labels have been normalized; outcomes are retained.


---

Original document: docs/buddy1-direct-join-fix.md

> Historical investigation record. For final results, remaining limitations and scope, see [Buddy 1 final review](BUDDY1_FINAL_REVIEW.md).

# Buddy 1: remove the preliminary scan dependency

Branch: `fix/buddy1-direct-wifi-join`, based on diagnostic commit `02bf883`.

## Finding and limits

On 29 October 2026, the user confirmed that the USB-disabled diagnostic image
on the power bank repeatedly produced exactly one flash per group, with no
MQTT messages. In that image, one flash means `scan_complete` remains false.
The ongoing LED groups indicate repeated diagnostic execution, unlike the
earlier USB-enabled run that reportedly became permanently dark.

The probable immediate blocker in this run is the application's **unbounded
dependency on completion of a preliminary diagnostic scan**. The old radio
task only issued the first `cyw43_wifi_join()` after detecting scan completion.
Its join retry could not help because no join had started. This explains why
the MQTT layer could remain inactive even though its own retry tests passed.

This does not establish why scan completion was not observed on power-bank
power, or explain every earlier result. No physical pass is claimed for the
updated firmware. The reported persistent one-flash pattern, source inspection,
and host regression support this targeted change; they do not prove the radio
or supply behaves correctly under all conditions.

## Small runtime change

Only `lib/libwifi/sysdepend/pico_rp2040/cyw43_utk.c` changes relative to the
diagnostic branch:

- Lines 522-529: MQTT builds do not request the preliminary diagnostic scan.
  Non-MQTT qualification builds retain it.
- Line 546: the diagnostic scan-active flag stays false when no scan ran.
  The code does not falsely mark a skipped scan as completed.
- Lines 619-637: MQTT starts its first join directly after radio setup, using
  the existing SSID/password. The existing five-second failed-join retry,
  thirty-second pending-join timeout and late-success protection remain.
- Lines 454-476: the LED no longer waits on the skipped scan. Link/IP/MQTT
  patterns remain 2/3/4, with solid indicating MQTT at the last owner poll.

The installed Pico SDK follows the same direct-join approach in
`src/rp2_common/pico_cyw43_arch/cyw43_arch.c:93`: its asynchronous connection
helper calls `cyw43_wifi_join()` without requiring a separate diagnostic scan.
Joining the configured SSID still performs the radio's necessary AP discovery.

No MQTT adapter, kernel, USB service, credentials, topic, broker address,
teammate implementation or motor behavior changes in this fix. No blind radio
reset, static IP or extra task is added. Radio initialization failure still
requires separate diagnosis.

## Software checks

`tools/test_wifi_startup.py` now exercises the production setup and join blocks.
The old MQTT source fails the new no-preliminary-scan assertion; the corrected
source passes. Both MQTT and non-MQTT checks cover:

- setup failure, and absence of preliminary scan calls in MQTT builds;
- joining without a scan-complete event, including stale scan-state flags;
- no overlapping join or duplicate join when a late scan event arrives;
- cooldown, initial request rejection, terminal error and pending timeout;
- preserving a late successful link; qualification scan/one-shot behavior.

The LED test is updated to expect joining rather than the removed scan stage.
All 11 network scenarios still pass, including real lwIP MQTT handshake,
subscription and heartbeat; real Buddy 1 telemetry forwarding with exact
payload checks; fragmented START and normal STOP through the parser and
consumer with simulated kernel queues; wrong-topic and invalid-command
rejection. The tests invoke no hardware or live motor command.

Run from the repository root with host GCC available:

```powershell
python tools/test_wifi_startup.py
python tools/buddy1_startup_tests/run_network_tests.py --sdk C:/Users/muhdh/.pico-sdk/sdk/2.3.1
python tools/buddy1_startup_tests/test_led_diagnostic.py
```

## Firmware and first test

**Test `buddy1-direct-join-no-usb.uf2` first.** This retains the USB-disabled
profile from the last observed one-flash failure, so the comparison changes
the scan/join startup logic rather than re-enabling USB at the same time.

Artifacts are in:

```text
$env:LOCAL_ARTIFACTS
```

Primary UF2 SHA256:
`5a0c6c55fb29d9a15bd1d60fb41f2ef9f508bbb21d6e56914e097a23335b37d1`.

1. Keep the same hotspot, broker and subscriber running. Confirm the laptop's
   hotspot IP remains `172.20.10.2`. The dashboard must use that broker too;
   its earlier connection to a separate localhost broker was corrected.
2. Disconnect board power. Hold Pico W **BOOTSEL** while connecting its USB
   cable to the laptop. Release when **RPI-RP2** appears.
3. Copy **buddy1-direct-join-no-usb.uf2** to RPI-RP2. Allow it to restart and
   observe laptop-USB startup without COM5. COM5 is intentionally unavailable
   in this image. Confirm fresh heartbeat and telemetry on the subscriber.
4. Leave the car-side plug in the exact same socket. Disconnect only the
   laptop end for ten seconds, then plug it into the **existing power bank**.
   Do not hold BOOTSEL; use no wall charger and change no other wiring.
5. Observe for three minutes. A successful run requires a **new** broker
   connection identifying `picocar-vehicle1`, plus advancing heartbeat and
   telemetry sequences. An old connection, dashboard Online alone, or the
   subscriber's own PINGRESP is insufficient.
6. If successful, repeat three complete power-bank cold starts. Record the
   firmware name/hash, power-on time, LED pattern, new car connection time/IP,
   first heartbeat and telemetry progression for each run.

| LED on updated image | Meaning at last checkpoint |
|---|---|
| 2 flashes per group | Wi-Fi joining / link down |
| 3 flashes per group | Link up, interface or IPv4 not usable yet |
| 4 flashes per group | IPv4 usable, MQTT not connected |
| Solid | MQTT connected at last poll; confirm continuing messages |
| 5 flashes | Initialization error, if radio LED access remains possible |
| Dark/frozen | Ambiguous: execution, radio/LED I/O or power may be involved |

Groups still repeat every four seconds. The one-flash scan code is removed.
If a single-flash pattern persists, record the exact flashed filename and the
timing before drawing conclusions. No physical command test is needed during
this startup comparison; commands were exercised in software without motors.

The same source also builds `buddy1-direct-join-usb.uf2` with USB CDC restored.
Keep that for a later comparison after the USB-disabled result is known. A
successful no-USB run alone cannot establish that USB-enabled standalone
startup is fixed, especially given the earlier dark-LED observation.

Rollback through BOOTSEL using `buddy1-no-usb-diagnostic.uf2` (previous comparison)
or `existing-before-investigation.uf2` (preserved original). No images were
flashed during this preparation step.

## Build reproduction

Builds use the separate investigation source copy, preserving repository build
outputs. Arm GCC 15.2.1 and Pico SDK 2.3.1 are installed. From its `build_make`
directory:

```powershell
$env:PATH = 'C:\Users\muhdh\.pico-sdk\toolchain\15_2_Rel1\bin;C:\raylib\w64devkit\bin;' + $env:PATH
make SMP=0 CONSOLE=uart WIFI=cyw43 WIFI_JOIN=1 WIFI_NETIF=1 WIFI_DHCP=1 WIFI_DNS=1 WIFI_MQTT=1 PICO_SDK_PATH=C:/Users/muhdh/.pico-sdk/sdk/2.3.1 'TEMP_SRCS=../app_program/app_main.c $(wildcard ../app_program/buddy1/*.c) $(wildcard ../app_program/buddy5/*.c)' -j8
```

For the later USB-enabled comparison, replace only `CONSOLE=uart` with
`CONSOLE=usb_cdc`. Both source selections match the current `app_main.c`:
Buddy 1 and Buddy 5. Neither build modifies teammates' sources.

Logs are `repo/build-direct-join-no-usb.log`, `repo/build-direct-join-usb.log`,
`direct-join-regression-before.log` and `direct-join-regression-after.log` in
the investigation folder. Firmware hashes are in `firmware/direct-join-build.json`.

---

Original document: docs/buddy1-powerbank-windows-test.md

> Historical investigation record. For final results, remaining limitations and scope, see [Buddy 1 final review](BUDDY1_FINAL_REVIEW.md).

# Windows: Buddy 1 standalone startup diagnostic

Branch: `diagnostic/buddy1-powerbank-startup`.

**This is a diagnostic build, not a confirmed power-bank fix.** Source review
has not established a probable hardware root cause. The earlier initial-join
retry handles a real missing recovery path, but the recorded power-bank run
still failed. This branch retains that retry and adds an owner-task LED stage
indicator so the next change can target the observed failure.

The build starts the existing Buddy 1 and Buddy 5 application only. No teammate
source, motor behavior, Wi-Fi credentials, broker endpoint or topic is changed.
The consumer in `app_program/buddy1/command.c` still only logs commands.
This preparation record does not claim a physical test or firmware flash.

## Source and findings

- `app_program/buddy1/network.c:39`: USB wait affects status printing only.
- `kernel/sysdepend/pico_rp2040/devinit.c:101,107`: USB and radio start separately.
- `lib/libwifi/sysdepend/pico_rp2040/cyw43_utk.c`: owns radio polling, DHCP timers
  and MQTT polling. Setup/scan errors can prevent startup; their occurrence
  on the physical power-bank boot is unknown. Its new `startup_led_poll()`
  runs in that same task and never drives a motor pin.
- `lib/libnet/lwip/mqtt_utk.c`: live interface/link/IPv4 gate, existing retries,
  and an owner-only connection-state getter for the indicator. MQTT retry
  failures were not reproduced in software.
- `lib/libnet/lwip/mqtt_utk.h`: declares that getter.

The indicator uses **CYW43 GPIO 0**, the small LED on the Pico W module.
It does not use RP2040 GPIO 25, which is the radio chip select on Pico W.
LED I/O occurs on transitions, with an initialized-radio guard. It does add
radio transactions and can alter timing: a successful diagnostic run alone
does not prove the original firmware or a later non-diagnostic fix works.

## 1. Locate and preserve the images

In PowerShell:

```powershell
$bundle = '$env:LOCAL_ARTIFACTS'
Get-FileHash "$bundle\buddy1-powerbank-diagnostic.uf2" -Algorithm SHA256
```

The matching hash and build information are in `powerbank-diagnostic-build.json`
in that folder. The preserved rollback image is `existing-before-investigation.uf2`.
Keep both. Firmware contains the existing Wi-Fi configuration; keep it private.

## 2. Prepare the laptop before flashing

1. Enable the same iPhone hotspot and connect the laptop to it.
2. Run `ipconfig`. Confirm the laptop's hotspot-facing IPv4 is `172.20.10.2`,
   the broker address compiled into this image. If it changed, stop this test
   and update the firmware configuration/build to match the actual address.
3. Keep the existing Mosquitto broker and dashboard running. Do not start a
   second broker. Keep its verbose connection log visible, ideally with
   `connection_messages true` and `log_type all` in its existing configuration.
4. Close COM5 and any application that automatically opens it.
5. Start this independent observer in another PowerShell window:

   ```powershell
   & 'C:\Program Files\mosquitto\mosquitto_sub.exe' -h 172.20.10.2 -p 1883 -i picocar-powerbank-observer -t 'picocar/vehicle1/#' -v -R -d
   ```

   Its own CONNACK/SUBACK and PINGRESP confirm only the observer's connection.
   Never use `picocar-vehicle1` as the observer's client ID. `-R` excludes retained
   messages. Do not publish a network-test message to `/status` or `/telemetry`:
   that can make the dashboard appear Online without a working car.

## 3. Flash using laptop USB

1. Disconnect the board from the power bank and every other power source.
2. Hold **BOOTSEL on the Pico W module**, then connect the board USB port to
   the laptop using the existing data cable. Release BOOTSEL once Windows
   shows the **RPI-RP2** drive. This is a storage drive, not COM5.
3. In File Explorer, copy `buddy1-powerbank-diagnostic.uf2` onto RPI-RP2.
   The drive should disappear as the board restarts. Copying the file is the
   flash operation; do not open COM5 afterward.
4. Leave it on laptop USB for up to three minutes. Look for a new broker
   connection identifying **picocar-vehicle1**, a solid Pico W LED, fresh
   `heartbeat seq=N` messages about every five seconds and changing telemetry
   about once a second. Record the broker connection time and source IP.
5. If this baseline fails, record the LED pattern and broker output before
   proceeding. A failed laptop baseline cannot isolate the power-bank issue.

## 4. Cold-start using the existing power bank

1. Leave the laptop broker, observer and hotspot running. Keep COM5 closed.
2. Disconnect all power from the board for ten seconds. Do not hold BOOTSEL.
3. Connect the same board USB port and cable to the **existing power bank**.
   Use no wall charger. Record the power-on time, for example with
   `Get-Date -Format o` in PowerShell.
4. Watch the small Pico W LED for 15-20 seconds to count complete groups, then
   observe the broker/subscriber for three minutes. Record pattern changes.
5. Look for a **new** broker connection after power-on identifying
   `picocar-vehicle1`, followed by increasing heartbeat and telemetry sequences.
   An old connection timing out, hotspot count, dashboard Online alone, or the
   observer's PINGRESP does not establish a fresh car connection.
6. If successful, repeat three complete power-bank cold starts. Record each
   run independently. This tests automatic startup without ever opening COM5.

| Pico W LED, groups repeating every four seconds | Last observed stage |
|---|---|
| 1 flash | Preliminary scan has not completed |
| 2 flashes | Scan completed; Wi-Fi link down / joining |
| 3 flashes | Link up, but interface or IPv4 not yet usable |
| 4 flashes | Interface and IPv4 usable; MQTT not connected |
| 5 flashes | Scan-start/setup error after the STA interface initialized |
| Solid | MQTT was connected at the last radio-task poll |
| Dark, or frozen state | Ambiguous; boot, radio initialization, LED I/O or task progress may be involved |

A frozen solid LED is not proof of ongoing MQTT. Use fresh broker messages.
Three flashes do not by themselves prove DHCP server failure; four flashes
do not prove the laptop broker received a connection attempt.

## 5. Command check and what software already verified

Host tests exercise real lwIP MQTT and the unchanged Buddy 1 code: subscription
to `/command`, fragmented START and normal STOP through the real parser and
consumer with simulated queues, invalid-command/wrong-topic rejection, and
telemetry forwarding with exact topic/payload checks. No motor code is linked.

An optional physical command check can be made on laptop USB **after** verifying
automatic MQTT startup with COM5 closed: open COM5 using the existing terminal
settings, then send only STOP from PowerShell:

```powershell
& 'C:\Program Files\mosquitto\mosquitto_pub.exe' -h 172.20.10.2 -p 1883 -t 'picocar/vehicle1/command' -m 'STOP'
```

The board should log `[MQTT] RX ... payload=STOP` and `[Command] type=STOP ...`.
Seeing your own STOP in the subscriber does not prove the board consumed it.
There is currently no command acknowledgment topic, so broker/subscriber output
alone cannot prove command-consumer execution on power-bank power. This optional
serial check is separate from the standalone startup test; close COM5 afterward.

## Rollback and next evidence

Repeat the BOOTSEL procedure and copy `existing-before-investigation.uf2` to
RPI-RP2 to restore the preserved firmware. Do not change teammate sources.

Record: firmware hash; power source; power-on time; LED pattern over time;
new car connection time/IP; first and last heartbeat; telemetry progression.
The missing observation is the first stalled stage on a power-bank cold boot.
That evidence determines a minimal targeted fix; the current branch does not
claim to make standalone startup reliable.

## Rebuild and software checks

Builds were performed in the separate investigation source copy to preserve
the original repository's existing firmware artifacts. Arm GCC 15.2.1 and
Pico SDK 2.3.1 were used. From that copy's `build_make` directory:

```powershell
$env:PATH = 'C:\Users\muhdh\.pico-sdk\toolchain\15_2_Rel1\bin;C:\raylib\w64devkit\bin;' + $env:PATH
make -B SMP=0 CONSOLE=usb_cdc WIFI=cyw43 WIFI_JOIN=1 WIFI_NETIF=1 WIFI_DHCP=1 WIFI_DNS=1 WIFI_MQTT=1 PICO_SDK_PATH=C:/Users/muhdh/.pico-sdk/sdk/2.3.1 'TEMP_SRCS=../app_program/app_main.c $(wildcard ../app_program/buddy1/*.c) $(wildcard ../app_program/buddy5/*.c)' -j8
```

The explicit source list matches `app_main.c` and avoids unrelated standalone
Buddy 2/3 test sources that fail the unfiltered application build. It changes no
teammate implementation. SDK 2.3.1 differs from the README's 2.2.0 baseline.

From the branch repository root, with host GCC available:

```powershell
python tools/test_wifi_startup.py
python tools/buddy1_startup_tests/run_network_tests.py --sdk C:/Users/muhdh/.pico-sdk/sdk/2.3.1
python tools/buddy1_startup_tests/run_usb_tests.py
python tools/buddy1_startup_tests/test_led_diagnostic.py
```

Passing software checks and a firmware build do not constitute physical tests.

---

Original document: docs/buddy1-standalone-startup.md

> Historical investigation record. For final results, remaining limitations and scope, see [Buddy 1 final review](BUDDY1_FINAL_REVIEW.md).

# Buddy 1 standalone startup investigation — 28 October 2026

The power-bank failure remains **unresolved**. The user flashed the retry
firmware; it worked on laptop USB, but no fresh car connection or numbered
heartbeat was observed in the subsequent power-bank run. The user reports the
extra hotspot device stays connected; its DHCP address remains unverified.
No motor command was sent during the investigation. See
[the software follow-up](buddy1-startup-software-findings.md) for source findings
and host tests. Further electrical comparisons are paused; wall chargers are
excluded at the user's request.

## Findings from the local source

Baseline: `b4e9a2b`. The local `dashboard/` directory was already untracked.

- `app_program/buddy1/network.c:39` waits for USB enumeration, but this task
  only reports status. It does not start or poll the radio or MQTT.
- `kernel/sysdepend/pico_rp2040/devinit.c` starts the USB and radio services
  independently. The USB task has priority 3 and the radio task priority 4.
  The USB producer uses a finite ring and drops excess output; it does not
  wait for a host. No host-dependent wait was found on the inspected network
  startup path. This does not rule out a hardware or lower-level USB fault.
- `lib/libwifi/sysdepend/pico_rp2040/cyw43_utk.c` initializes the radio, scans,
  and joins after scan completion. Before this patch, an immediate join error,
  terminal link error, or 30-second join timeout had no application retry.
  The driver also has internal retries for certain authentication events;
  those do not replace the missing application retry for all failures.
- Radio/bus or scan-request failure still parks the radio service. A scan
  that never completes still prevents joining. These are separate unresolved
  possibilities; adding blind hardware resets without evidence was avoided.
- `lib/libnet/lwip/mqtt_utk.c` polls independently of the status-report task.
  It requires interface up, link up, and nonzero local IPv4, then attempts
  `172.20.10.2:1883` as `picocar-vehicle1`. It retries failed MQTT connections
  with a 3-second interval once the asynchronous attempt finishes. A TCP
  attempt can take longer than three seconds to fail. DNS test completion
  is not a runtime gate for this numeric-IP broker connection.
- DHCP's 30-second completion flag is diagnostic. lwIP timeouts continue
  running afterward, and MQTT checks the live address, not that flag. A later
  lease can therefore permit MQTT even if the DHCP report says timed out.
- The local `dashboard/app.py:33` timestamps every received message, and
  `:78` treats a `/status` timestamp younger than 15 seconds as a heartbeat.
  A manual publication to `/status` can make it appear Online. The later
  retry-run capture contained `network-test` on `/status`; publisher identity
  was unavailable. The earlier chat's test payload/topic remain unknown.
  The dashboard was not edited.
- `app_program/app_main.c` starts Buddy 1 and Buddy 5. Buddy 1's command
  consumer currently logs commands; this patch does not add motor operations.

## Focused changes

- `lib/libwifi/sysdepend/pico_rp2040/cyw43_utk.c:46,458,567`: MQTT builds retry
  a failed initial join five seconds after failure. In-progress joins are not
  overlapped, and a late successful link prevents retry. Scan/join qualification
  profiles retain their one-shot behaviour. This is not a full reconnection
  policy after a previously successful association is lost.
- `lib/libnet/lwip/mqtt_utk.c:414,562`: existing five-second debug output now
  includes interface/link/IP; each broker attempt logs client ID, endpoint
  and uptime. These logs do not depend on opening COM5 to advance networking.
  USB buffering is finite, so attaching a terminal later is not a guaranteed
  complete startup capture. Under power-bank-only operation use broker logs.
- `tools/test_wifi_startup.py`: compiles the production join-control block with
  a fake clock/radio. It tests immediate failure, cooldown, pending attempt,
  timeout, terminal failure, success, late success, and non-MQTT behaviour.

## Validation and build

The regression check passes with `TM_WIFI_MQTT=0` and `=1`:

```powershell
python tools/test_wifi_startup.py
```

A native Windows build linked and produced UF2 using installed Arm GCC
15.2.1 and Pico SDK **2.3.1**. This differs from the README's SDK 2.2.0
qualification baseline; existing local object dependencies also used 2.3.1.
No physical behaviour is inferred from a successful build.

The unfiltered application build fails on unrelated Buddy 2/3 standalone
source dependencies (`pico/stdlib.h`, `motion_control.h`). `BUDDY1_ONLY=1`
alone also excludes Buddy 5 while `app_main.c` calls it. The successful build
therefore explicitly selects exactly the application sources currently used:

```powershell
$env:PATH = 'C:\Users\muhdh\.pico-sdk\toolchain\15_2_Rel1\bin;C:\raylib\w64devkit\bin;' + $env:PATH
Set-Location build_make
make SMP=0 CONSOLE=usb_cdc WIFI=cyw43 WIFI_JOIN=1 WIFI_NETIF=1 WIFI_DHCP=1 WIFI_DNS=1 WIFI_MQTT=1 PICO_SDK_PATH=C:/Users/muhdh/.pico-sdk/sdk/2.3.1 'TEMP_SRCS=../app_program/app_main.c $(wildcard ../app_program/buddy1/*.c) $(wildcard ../app_program/buddy5/*.c)' -j8
```

Builds were run in the separate investigation copy, preserving the original
repository's firmware artifacts. This command in the original repository
would overwrite that profile's output, so save it elsewhere first.

## Optional later test without COM5

The current plan is source inspection and software tests. The following is a
reference for a later user-controlled test, not a request to change power now.

1. Keep the broker, dashboard, and laptop on the same iPhone hotspot. Confirm
   the laptop's current Wi-Fi IPv4 is **172.20.10.2** with `ipconfig`; a changed
   address requires matching firmware broker configuration. Ensure the existing
   broker listener and firewall still accept LAN connections. A local dashboard
   connection by itself does not verify this.
2. Keep the existing broker's verbose console or file log visible. If necessary,
   enable `connection_messages true` and `log_type all` in its existing config,
   retaining its current listener/authentication settings. Start logging before
   the test. Do not launch a competing broker on port 1883. Official reference:
   https://mosquitto.org/man/mosquitto-conf-5.html
3. Start a separate subscriber; `-R` suppresses retained messages delivered on
   subscription. Use a unique observer client ID, never `picocar-vehicle1`:

   ```powershell
   & 'C:\Program Files\mosquitto\mosquitto_sub.exe' -h 172.20.10.2 -p 1883 -i buddy1-startup-observer -t 'picocar/vehicle1/#' -v -R
   ```

   Official option reference: https://mosquitto.org/man/mosquitto_sub-1.html
4. First test the existing firmware. Power the board completely off between
   runs; use the same cable and board USB socket for laptop USB (COM5 closed)
   and the existing power bank only. Do not use a wall charger. Record power-on
   time and observe
   each run for at least 120 seconds. Keep motors disabled as in the current
   firmware. Do not send START or publish anything to `/status` or `/telemetry`.
5. Look for a **new**, timestamped broker entry such as `New client connected
   from <board-IP>:<port> as picocar-vehicle1`, followed by status/telemetry
   publications from that client. An old connection timing out is not a fresh
   connection. Observe increasing `heartbeat seq=N` about every five seconds
   and live telemetry about once per second. Subscriber messages alone do not
   identify the publisher; correlate them with the broker log.
6. Repeat with the separate retry test UF2 only when ready to flash it. Retain
   the preserved original UF2 for rollback. Also test cold boot with the hotspot
   initially unavailable, enabling it after about 45 seconds; this specifically
   exercises initial join recovery. Do not change firmware and power source
   together in a comparison.

| Observation | What it establishes / next evidence |
|---|---|
| iPhone connected-device count rises | Supporting association evidence only; does not prove a DHCP lease, unique device identity, or MQTT. |
| New broker TCP connection from board IP only | IP communication reaches the laptop; check for MQTT CONNECT/client acceptance next. |
| New accepted `picocar-vehicle1` connection and its publications | Fresh MQTT startup works for that run; record source IP and timestamps. |
| No new broker connection | Association, DHCP, routing, firewall, or boot may still be failing; broker silence alone cannot separate them. |
| Laptop USB works with COM5 closed; power bank fails | Host/power-dependent startup remains a hypothesis; the diagnostic-task USB wait is still not proof. |
| New connection followed by failure without unplugging | Record disconnect/reconnect timing; investigate runtime recovery separately. |

For the no-connection case, a Wireshark capture on the laptop's hotspot Wi-Fi
interface with `arp || bootp || tcp.port == 1883` may provide positive evidence:
a DHCP ACK addressed to the board proves a lease, an ARP request from a nonzero
board IP proves that it uses that address, and SYN/CONNECT/CONNACK distinguish
TCP from MQTT. Identify the board by its MAC or known baseline address first.
An ordinary laptop capture may not see other clients' unicast DHCP exchanges;
missing packets do not establish DHCP failure. `arp -a` is a supporting cache,
not the iPhone's DHCP lease table. A static IP should not be guessed.

If still unresolved, obtain owner-task LED stage diagnostics or an independent
UART capture in a subsequent focused change. The Pico W LED is radio-driven,
so it cannot by itself diagnose a radio initialization failure. No LED pin or
teammate subsystem was changed here.

Save one row per run: firmware filename/hash, power source, power-on time,
hotspot count before/after, new board connection time/IP, first heartbeat,
last heartbeat, and relevant broker lines. Those observations are needed before
claiming that power-bank startup is fixed.

---

Original document: docs/buddy1-startup-software-findings.md

> Historical investigation record. For final results, remaining limitations and scope, see [Buddy 1 final review](BUDDY1_FINAL_REVIEW.md).

# Buddy 1: source and software investigation, 28 October 2026

**Standalone operation remains unresolved.** The retry firmware did not restore
observable MQTT during the recorded power-bank run. The user reported that the
extra hotspot device remained connected, but no fresh car TCP connection or
numbered heartbeat was observed. Association evidence does not establish DHCP.

This follow-up used source inspection and host software tests only. No board
was flashed, no broker traffic or motor command was sent, and no electrical
setup was changed during this follow-up. Wall-charger tests are excluded.

## 1. DHCP without USB enumeration

There is no USB-enumeration condition in the inspected DHCP path. In Pico SDK
2.3.1, `lib/cyw43-driver/src/cyw43_lwip.c:213-226` brings up the network interface
and starts DHCP; its link-up callback at line 293 updates lwIP. With no link,
DHCP waits in INIT. Link-up starts discovery. The radio owner's regular
`sys_check_timeouts()` call (`cyw43_utk.c:519`) advances DHCP timers.

The tests ran the real lwIP DHCP implementation with synthetic Ethernet
OFFER/ACK packets and verified the assigned IP, gateway, DNS and lease state.
Both an immediate server response and one delayed by 45 simulated seconds
succeeded without USB code. MQTT made no connection attempt before an IP was
available. This verifies the protocol path, **not DHCP on the physical board**.

`cyw43_utk.c:397-428` latches its diagnostic DHCP result after 30 seconds.
A later lease can leave that report saying timeout: the diagnostic stops
updating, while lwIP continues running. MQTT checks the live interface address,
so this stale report does not itself block the numeric-IP broker connection.

## 2. Reaching mqtt_client_connect()

The radio task calls `mqtt_utk_poll()` at `cyw43_utk.c:529`, independently of the
USB-gated status-printing task in `app_program/buddy1/network.c:39`.
`mqtt_utk.c:440` requires interface-up, link-up and nonzero IPv4. It does not
require USB, the diagnostic DHCP-complete flag, or DNS test completion.

Once those conditions hold, client allocation at `mqtt_utk.c:474` resets the
attempt timestamp. The initial `mqtt_client_connect()` at line 570 therefore
occurs three seconds after successful allocation. The synthetic peer test
observed this call, completed TCP and MQTT handshakes, and received a heartbeat.
Thus this source can reach CONNECT without USB; reaching it on power-bank
hardware remains unverified.

## 3. Initial MQTT failure recovery

The full production MQTT adapter and real lwIP were exercised together.
Immediate failure clears `connecting` at `mqtt_utk.c:581`. Asynchronous
TCP/MQTT outcomes invoke `connection_callback()` at line 203, which clears it
at line 212. The application retries after a three-second cooldown once the
attempt has ended; it deliberately does not overlap a pending attempt.

| Injected condition | Observed software behavior |
|---|---|
| Immediate connect-call error | Retry after 3 seconds |
| First client allocation fails | Allocation retries after 3 seconds; CONNECT 3 seconds later |
| No broker ARP response | Next attempt 33.75 seconds after the first |
| ARP works, TCP SYN unanswered | Next attempt 21.25 seconds after the first |
| TCP explicitly refused | Retry 3 seconds after refusal |
| TCP established, no MQTT CONNACK | Next attempt 103 seconds after the first |
| MQTT CONNACK rejects client as unavailable | Retry 3 seconds after rejection |
| Successful TCP/MQTT exchange | Connected state and heartbeat publication |

These are deterministic simulated timings with SDK 2.3.1, the repository's
lwIP configuration and a 10 ms test polling interval, not hardware guarantees.
TCP connection setup uses TCP's own timers. The MQTT CONNECT timeout starts
only after TCP connects (`SDK lib/lwip/src/apps/mqtt/mqtt.c:1070-1073`). All
timeout-based recovery depends on the radio task continuing to service lwIP.
No stuck initial-MQTT retry state was reproduced under these conditions.

## 4. USB initialization and scheduling

`kernel/sysdepend/pico_rp2040/devinit.c:101,107` starts the USB and radio
services separately. USB is priority 3; radio is priority 4, both on core 0
in the tested SMP=0 profile. Higher-priority USB activity can therefore affect
radio scheduling even though enumeration is not a network prerequisite.

The real USB console implementation was compiled against a fake kernel and
TinyUSB boundary. With 10,000 output bytes and no host it retained 4,095 bytes,
dropped 5,905 and requested its normal 10 ms sleep. The same held with an
enumerated host accepting no data. A finite 100-event burst drained and then
slept. A failed TinyUSB initialization exited the service task.

Relevant source is `lib/libtm/sysdepend/pico_rp2040/usb/usb_console.c:160,175,208,283`.
This rules out an unconditional host wait or full-ring wait at that boundary.
The tests replace TinyUSB initialization and do not emulate RP2040 interrupts.
`usb_sdk_compat.c:47-59` wakes the task on every USB interrupt; a sustained event
stream or accumulated wakeups could delay lower-priority work. No such storm
has been measured. Enumeration workaround waits are disabled in the project's
`usb/pico/config_autogen.h:17-18`; this is source evidence, not a hardware check.

## 5. Controlled firmware changes and remaining failure paths

The existing five-second initial Wi-Fi join retry remains appropriate and its
regression checks pass for MQTT=0 and MQTT=1. It handles rejected, timed-out
and terminally failed initial joins without overlapping attempts or disturbing
a late successful link. It does not implement recovery after a previously
successful Wi-Fi association is lost.

Two earlier gates remain in the production radio task:

- Radio setup or scan-start error reaches the permanent sleep at
  `cyw43_utk.c:484-510`. In this case neither DHCP nor MQTT polling runs.
- A scan that never finishes prevents the first join at
  `cyw43_utk.c:563-584`. Polling runs, but there is no join request.

These are real source failure paths, but neither has been demonstrated on the
power bank. Removing the preliminary scan only for MQTT builds is a possible
small follow-up if scan failure is established; it would not repair DHCP,
USB interrupt starvation or radio initialization failure. Adding a second MQTT
retry loop is not justified by the passing protocol tests.

No further runtime patch or new firmware is introduced by this follow-up.
The separate, previously prepared LED diagnostic remains an optional later
hardware observation tool, not a reliability fix. Its radio writes can alter
timing and its frozen state only represents the last successful poll.

## Reproduction and limits

Added `tools/buddy1_startup_tests/` contains the two runners, C harnesses and
README. Run from the repository root:

```powershell
python tools/buddy1_startup_tests/run_network_tests.py --sdk C:/Users/muhdh/.pico-sdk/sdk/2.3.1
python tools/buddy1_startup_tests/run_usb_tests.py
python tools/test_wifi_startup.py
```

Results: 10 network scenarios, 4 USB scenarios, and both existing Wi-Fi join
configurations pass. Network tests use the actual repository MQTT source,
not the workspace-only LED variant. They use host GCC, simulated time and
packets; 64-bit host heap alignment is the only lwIP option override. Console
and Buddy IPC are stubbed; command ingestion is forbidden by an assertion.
No board, sockets or live broker are involved.

Only test/documentation files were added or updated in this follow-up, so no
new firmware build was needed. The earlier retry and LED images already built
with Arm GCC 15.2.1 / SDK 2.3.1 in a separate tree. Those builds do not establish
standalone behavior. Existing firmware artifacts and teammate subsystems remain
untouched. A reliable physical startup claim still requires observing a new
board connection after a standalone cold boot.
