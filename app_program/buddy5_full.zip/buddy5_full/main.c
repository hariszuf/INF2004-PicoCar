#ifdef B5_FULL_TEST
#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include "platform.h"
#include "line_test.h"
#include "full_nav.h"
#include "../buddy1/buddy1.h"
#include "buddy5_servo.h"
#include "../buddy5/ultrasonic.h"
#include "../buddy2/motion_control.h"
#include "../buddy3/line_follow.h"
#include "../buddy3/line_sensors.h"
#include "../buddy3/line_config.h"
#if TK_SUPPORT_SMP
#error "This integration profile requires SMP=0"
#endif
#if CNF_TIMER_PERIOD != 1
#error "Use full_test.mk (1ms kernel tick required)"
#endif
#if TM_CONSOLE_UART
#error "GP0 belongs to the line sensor: this profile requires USB-only console"
#endif
IMPORT UW tm_usb_state(void);
static b5_feedback_t feedback_shared;
static b5_request_t pending_request;
static bool request_pending;
static volatile bool run_enabled;
static volatile bool user_stop_pending;
static unsigned char commands[8];
static unsigned command_head,command_tail;
bool b5_line_usb_connected(void) { return tm_usb_state()>=3; }
void b5_line_command_received(unsigned c) {
 UW irq;
 if(c!='R' && c!='G' && c!='S' && c!=' ') return;
 DI(irq);
 if(c=='S' || c==' ') {
  user_stop_pending=true; command_tail=command_head;
 } else if(b5_line_usb_connected()) {
  unsigned next=(command_head+1u)%8u;
  if(next==command_tail) { user_stop_pending=true; command_tail=command_head; }
  else { commands[command_head]=(unsigned char)c; command_head=next; }
 }
 EI(irq);
}
bool b5_line_take_stop(void) {
 UW irq; bool stop;
 DI(irq); stop=user_stop_pending; user_stop_pending=false; EI(irq);
 return stop;
}
int b5_line_take_command(void) {
 UW irq; int c=-1;
 DI(irq);
 if(command_head!=command_tail) {
  c=commands[command_tail]; command_tail=(command_tail+1u)%8u;
 }
 EI(irq); return c;
}
static void discard_commands(void) { UW irq; DI(irq); command_tail=command_head; EI(irq); }
bool line_controller_feedback(b5_feedback_t *f) {
 UW irq; DI(irq); *f=feedback_shared; EI(irq); return f->valid;
}
bool line_controller_request(const b5_request_t *r) {
 UW irq; bool accepted=false;
 DI(irq);
 if((run_enabled || r->kind==B5_REQ_STOP) && (!request_pending || r->kind==B5_REQ_STOP)) {
  pending_request=*r; request_pending=true; accepted=true;
 }
 EI(irq); return accepted;
}
static void halt(full_nav_t *nav,const char *why) {
 run_enabled=false; nav->active=false; nav->moving=false;
 line_follow_stop(); motion_emergency_stop(); line_scan_abort(); discard_commands();
 tm_printf((UB*)"[FULL] STOPPED: %s. Clear cause, R then G.\n",(UB*)why);
}
static void controller_task(INT stacd,void *exinf) {
 motion_status_t motor; line_scan_status_t scan;
 full_nav_t nav;
 motion_update(); motion_get_status(&motor); full_nav_init(&nav,&motor);
 uint32_t now=buddy5_clock_ms(),last_motor=now,last_line=now,last_report=now;
 uint32_t armed_since=0,run_since=0,lost_since=0;
 unsigned arming=0;
 uint8_t mask=0;
 bool fault_latched=false;
 (void)stacd; (void)exinf;
 tm_printf((UB*)"[FULL] Boot STOPPED. R=arm; wait ARMED; G=go; S/space=stop.\n");
 for(;;) {
  now=buddy5_clock_ms();
  line_scan_get_status(&scan);
  int command=b5_line_take_stop()?'S':b5_line_take_command();
  if(command=='S') { halt(&nav,"user stop"); arming=0; }
  if((run_enabled || arming) && !b5_line_usb_connected()) {
   halt(&nav,"USB disconnected"); arming=0;
  }
  if(run_enabled && ((uint32_t)(now-run_since)>300000u ||
     (uint32_t)(now-scan.heartbeat_ms)>400u)) {
   halt(&nav,"run/scan heartbeat timeout"); arming=0;
  }
  if(run_enabled && scan.state==B5_ERROR) { halt(&nav,"obstacle subsystem fault (see SCAN)"); arming=0; }
  if((uint32_t)(now-last_line)>=5u) {
   last_line=now; mask=line_sensors_read();
   if(run_enabled && scan.state==B5_MONITORING && !nav.active) {
    if(!(mask&(LINE_SENSOR_LEFT|LINE_SENSOR_RIGHT))) {
     if(!lost_since) lost_since=now;
     if((uint32_t)(now-lost_since)>150u) halt(&nav,"line lost outside recovery");
    } else lost_since=0;
    if(run_enabled) line_follow_update();
   } else lost_since=0;
  }
  UW irq; bool got; b5_request_t request={0};
  DI(irq); got=request_pending; if(got) { request=pending_request; request_pending=false; } EI(irq);
  if(got && run_enabled) {
   if(!full_nav_accept(&nav,&request,now)) { halt(&nav,"request rejected"); arming=0; }
   else tm_printf((UB*)"[NAV] request=%d id=%u target_x/y=%d/%d\n",request.kind,(unsigned)request.id,request.forward_mm,request.lateral_mm);
  }
  bool guard=scan.angle==0 && scan.front_valid && scan.front_clearance_mm>150 &&
             (uint32_t)(now-scan.front_timestamp_ms)<=400u;
  if((uint32_t)(now-last_motor)>=20u) {
   if((uint32_t)(now-last_motor)>60u && run_enabled) { halt(&nav,"motor scheduling delay"); arming=0; }
   last_motor=now; motion_update(); motion_get_status(&motor);
   if(motor.fault==MOTION_FAULT_STALL) fault_latched=true;
   if(run_enabled && (motor.fault!=MOTION_FAULT_NONE || (nav.moving && !guard))) {
    halt(&nav,"motor fault or forward range unavailable"); arming=0;
   }
   full_nav_update(&nav,now,&motor,mask,guard);
   if(run_enabled && nav.failed) { halt(&nav,"navigation failed/pose mismatch"); arming=0; }
   if(nav.resumed) { tm_printf((UB*)"[FULL] LINE REACQUIRED: automatic line following resumed.\n"); nav.resumed=false; }
  }
  if(command=='R' && !run_enabled && nav.settled>=3) {
   line_follow_stop();
   if(motion_reset()==MOTION_OK) {
    motion_update(); motion_get_status(&motor); last_motor=now;
    full_nav_init(&nav,&motor); nav.settled=3;
    fault_latched=false; line_scan_reset(); arming=1; armed_since=now;
    DI(irq); request_pending=false; EI(irq); discard_commands();
    tm_printf((UB*)"[FULL] ARMING: awaiting fresh scan, line and >650mm front clearance.\n");
   }
  }
  if(arming==1 && (uint32_t)(now-armed_since)>600u && scan.state==B5_MONITORING &&
     guard && scan.front_clearance_mm>B5_STOP_FRONT_MM+50 && nav.line_seen>=3 &&
     motor.fault==MOTION_FAULT_NONE) {
   arming=2; tm_printf((UB*)"[FULL] ARMED. G starts full sequence.\n");
  }
  if(arming && (uint32_t)(now-armed_since)>15000u) { halt(&nav,"arming expired"); arming=0; }
  if(command=='G' && arming==2 && guard && scan.state==B5_MONITORING &&
     scan.front_clearance_mm>B5_STOP_FRONT_MM+50 && nav.line_seen>=3) {
   if(line_follow_start()) { run_enabled=true; run_since=now; arming=0; tm_printf((UB*)"[FULL] RUNNING.\n"); }
  }
  b5_feedback_t f;
  full_nav_feedback(&nav,last_motor,&f); f.fault=fault_latched;
  DI(irq); feedback_shared=f; EI(irq);
  if((uint32_t)(now-last_report)>=1000u) {
   tm_printf((UB*)"[FULL] enabled=%d mask=%u scan=%s fault=%d nav=%u/%u x/y=%d/%d heading=%d front=%d width=%d depth=%d..%d\n",
    run_enabled,(unsigned)mask,(UB*)b5_state_name(scan.state),scan.fault,nav.index,nav.count,
    (int)nav.x,(int)nav.y,(int)nav.heading,scan.front_clearance_mm,
    scan.profile.width_valid?scan.profile.width_mm:-1,
    scan.profile.depth_valid?scan.profile.depth_low_mm:-1,
    scan.profile.depth_valid?scan.profile.depth_high_mm:-1);
   last_report=now;
  }
  tk_dly_tsk(1);
 }
}
EXPORT INT usermain(void) {
 T_CTSK cfg={0};
 if(b5_platform_init()<E_OK || motion_init()!=MOTION_OK) return 1;
 motion_emergency_stop(); line_follow_init(); ultrasonic_init();
 if(!buddy5_servo_init() || buddy1_init()<E_OK) return 1;
 cfg.tskatr=TA_HLNG|TA_RNG3; cfg.task=controller_task; cfg.itskpri=4; cfg.stksz=4096;
 ID id=tk_cre_tsk(&cfg); if(id<0) return 1;
 if(tk_sta_tsk(id,0)<0) { tk_del_tsk(id); return 1; }
 if(buddy1_start()<E_OK || line_scan_start()<E_OK) { motion_emergency_stop(); return 1; }
 tk_slp_tsk(TMO_FEVR); return 0;
}
#endif